#include "CPU.h"
#include "ProcessorBase.h"

CPU::CPU():DEBUG(false),curCycle(FT),status(IDLE),PBNum(0)
{
	memset(&_MAR_,0,UnitLEN);
	memset(&_MDR_,0,UnitLEN);
	memset(&_IR_,0,UnitLEN);
	memset(&_PC_,0,UnitLEN);
	memset(&_SP_,0,UnitLEN);
	memset(&_PSW_,0,UnitLEN);
	memset(&_R0_,0,UnitLEN);
	memset(&_R1_,0,UnitLEN);
	memset(&_R2_,0,UnitLEN);
	memset(&_R3_,0,UnitLEN);
	memset(&_C_,0,UnitLEN);
	memset(&_D_,0,UnitLEN);
	InitMemory();
}

CPU::~CPU()
{}

void CPU::readIR()
{
	static _WORD addr,result;
	memcpy(&addr,&_PC_,UnitLEN);
	Read(addr,&result);
	memcpy(&_IR_,&result,UnitLEN);
	_PC_.STG = _PC_.STG + 1; 
}

MM_INT16* CPU::Register(REGISTER Register)
{
	switch(Register)
	{
		case MAR:
			return &_MAR_;
			break;
		case MDR:
			return &_MDR_;
			break;
		case IR:
			return &_IR_;
			break;
		case PC:
			return &_PC_;
			break;
		case SP:
			return &_SP_;
			break;
		case PSW:
			return &_PSW_;
			break;
		case R0:
			return &_R0_;
			break;
		case R1:
			return &_R1_;
			break;
		case R2:
			return &_R2_;
			break;
		case R3:
			return &_R3_;
			break;
		case C:
			return &_C_;
			break;
		case D:
			return &_D_;
			break;
		default:
			return NULL;
	}
}

//��Shell����
const MM_INT16* CPU::getRegister(REGISTER Register)
{
	return this->Register(Register);
}

OP CPU::getOPCode()
{
	switch(_IR_.DID.S1)
	{
		case 0:
			return MOV;
			break;
		case 1:
			return ADD;
			break;
		case 2:
			return SUB;
			break;
		case 3:
			return AND;
			break;
		case 4:
			return OR; 
			break;
		case 5:
			return EOR;
			break;
		case 6:
			return COM;
			break;
		case 7:
			return NEG;
			break;
		case 8:
			return INC;
			break;
		case 9:
			return DEC;
			break;
		case 10:
			return SL;
			break;
		case 11:
			return SR;
			break;
		case 12:
			return JMP;
			break;
		case 13:
			return RST;
			break;
		case 14:
			return JSR;
			break;
		default:
			return OP_ERROR;
	}
}

REGISTER CPU::getDRegister()
{
	switch(_IR_.DID.S2)
	{
		case 1:
			return MAR;
			break;
		case 2:
			return MDR;
			break;
		case 3:
			return IR;
			break;
		case 4:
			return PC;
			break;
		case 5:
			return SP;
			break;
		case 6:
			return PSW;
			break;
		case 7:
			return R0;
			break;
		case 8:
			return R1;
			break;
		case 9:
			return R2;
			break;
		case 10:
			return R3;
			break;
		case 11:
			return C;
			break;
		case 12:
			return D;
			break;
		default:
			return REGISTER_ERROR;
	}
}

REGISTER CPU::getSRegister()
{
	switch(_IR_.DID.S4)
	{
		case 1:
			return MAR;
			break;
		case 2:
			return MDR;
			break;
		case 3:
			return IR;
			break;
		case 4:
			return PC;
			break;
		case 5:
			return SP;
			break;
		case 6:
			return PSW;
			break;
		case 7:
			return R0;
			break;
		case 8:
			return R1;
			break;
		case 9:
			return R2;
			break;
		case 10:
			return R3;
			break;
		case 11:
			return C;
			break;
		case 12:
			return D;
			break;
		default:
			return REGISTER_ERROR;
	}
}

AM CPU::getDAM()
{
	switch(_IR_.DID.S3)
	{
		case 0:
			return R_0;
			break;
		case 1:
			return R_1;
			break;
		case 2:
			return R_2;
			break;
		case 3:
			return R_3;
			break;
		case 4:
			return R_4;
			break;
		default:
			return AM_ERROR;
	}
}

AM CPU::getSAM()
{
	switch(_IR_.DID.S5)
	{
		case 0:
			return R_0;
			break;
		case 1:
			return R_1;
			break;
		case 2:
			return R_2;
			break;
		case 3:
			return R_3;
			break;
		case 4:
			return R_4;
			break;
		default:
			return AM_ERROR;
	}
}

const string* CPU::getCurMicroCommand(int& len)
{
	len = this->microCommandLen;
	return this->microCommand;
}

void CPU::execute()
{
	readIR();
	int i = 0;
	static bool goOn;
	goOn = true;
	while(this->status==RUNNING&&goOn)
	{
		for(;i<PBNum;i++)
		{
			if(PB[i]->available(this->getOPCode()))
			{
				PB[i]->execute();
				this->CallBackShell(this);//֪ͨShell
				if(this->DEBUG)
				{
					goOn = false;
				}
				break;
			}
		}
		//��Чָ�������
	}
}

void CPU::CallBackCPU(ProcessorBase* pb)
{
	this->curCycle = pb->getCurCPUCycle();
	this->microCommand = pb->getCurMicroCommand(this->microCommandLen);
}

CPU_Cycle CPU::getCPUCycle()
{
	return this->curCycle;
}

CPU_Status CPU::getCPUStatus()
{
	return this->status;
}

int CPU::addPB(ProcessorBase* pb)
{
	if(PBNum<PBNUM)
	{
		PB[PBNum++] = pb;
		return 1;
	}
	return 0;
}

int CPU::prepare()
{
	if(this->status==IDLE)
	{
		this->status = PREPARED;
		int i = 0;
		for(;i<PBNum;i++)
		{
			this->PB[i]->setCallback(&CPU::CallBackCPU);//��΢�������ע��ص�����
		}
		return 0;
	}
	else
	{
		return 1;
	}
}

int CPU::start()
{
	if(this->status==PREPARED)
	{
		this->status = RUNNING;
		this->execute();
		return 0;
	}
	else
	{
		return 1;
	}
}

int CPU::stop()
{
	if(this->status==RUNNING)
	{
		this->status = STOP;
		return 0;
	}
	else
	{
		return 1;
	}
}

int CPU::restart()
{
	if(this->status==STOP)
	{
		this->status = RUNNING;
		this->execute();
		return 0;
	}
	else
	{
		return 1;
	}
}

int CPU::setIdle()
{
	if(this->status==STOP)
	{
		this->status = IDLE;
		int i = 0;
		for(;i<PBNum;i++)
		{
			this->PB[i]->setCallback(NULL);
		}
		return 0;
	}
	else
	{
		return 1;
	}
}

void CPU::nextOp()
{
	this->execute();
}
